from scapy.all import sniff, IP, TCP, UDP, ICMP
def process_packet(packet):
    if IP in packet:
        source = packet[IP].src
        destination = packet[IP].dst

        if TCP in packet:
            protocol = "TCP"
            source_port = packet[TCP].sport
            destination_port = packet[TCP].dport

        elif UDP in packet:
            protocol = "UDP"
            source_port = packet[UDP].sport
            destination_port = packet[UDP].dport

        elif ICMP in packet:
            protocol = "ICMP"
            source_port = "-"
            destination_port = "-"

        else:
            protocol = "Other"
            source_port = "-"
            destination_port = "-"

        print("\n[PACKET]")
        print(f"Source       : {source}")
        print(f"Destination  : {destination}")
        print(f"Protocol     : {protocol}")
        print(f"Source Port  : {source_port}")
        print(f"Destination  : {destination_port}")
        print("-" * 40)


print("=" * 40)
print("      CODEALPHA NETWORK SNIFFER")
print("=" * 40)
print("Capturing packets... Press Ctrl+C to stop.")

sniff(filter="ip", prn=process_packet, store=False)