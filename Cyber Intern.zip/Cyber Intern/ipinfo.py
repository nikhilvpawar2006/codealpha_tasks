import requests

ip = "20.184.175.10"

url = f"https://ipinfo.io/{ip}/json"

response = requests.get(url, timeout=10)

print("Status:", response.status_code)
print(response.text)